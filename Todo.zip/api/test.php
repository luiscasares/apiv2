<?php


 $password_hash = password_hash("makitaP0wer", PASSWORD_BCRYPT);
echo $password_hash; 
?>
//$2y$10$skiTHCe8uAaNQnDZ/WPX1urabH7IBtXDwt2x2Vx7IGUFf1WiE4vwa