<?php
require "../vendor/autoload.php";
use \Firebase\JWT\JWT;


$secret_key = "YOUR_SECRET_KEY";
$jwt = null;
$decoded = null ;

$data = json_decode(file_get_contents("php://input"));

$authHeader = $_SERVER['HTTP_AUTHORIZATION'];
$arr = explode(" ", $authHeader);

$jwt = $arr[1];
if($jwt){
    try {
        $decoded = JWT::decode($jwt, $secret_key, array('HS256'));
        // Access is granted. Add code of the operation here
       /*  echo json_encode(array(
            "message" => "Access granted:",
            "decoded" => $decoded
        )); */

    }catch (Exception $e){

    http_response_code(401);

    echo json_encode(array(
        "message" => "Access.",
        "error" => $e->getMessage()
    ));
    exit();

    }
} else {
    http_response_code(401);

    echo json_encode(array(
        "message" => "Access denied 11111.",
    ));
    exit();
} 
?>