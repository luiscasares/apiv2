<?php
 require './makefont/makefont.php';
 MakeFont('D:\\xampp\\htdocs\\WEB\\makita\\garantiaextendida\\api\\fpdf182\\helvetica-lt\\H.ttf','ISO-8859-1',false);

?>