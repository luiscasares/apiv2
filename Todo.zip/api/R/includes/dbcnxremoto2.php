<?php
/**
 * Conexión a la BD usando PDO en MySQL
 * V 1
 * Autor: Refill Creativo 
 */
$dnspdo ='mysql:host=localhost;dbname=rcreativ_distribuidoresm2';
$username="rcreativ_distriempresa";
$passwd="AYY1Q1tndtf8XfAv";
try {
    $pdocnx = new PDO($dnspdo, $username, $passwd);
} catch (PDOException $exc) {
    echo $exc->getTraceAsString();
    echo $exc->getMessage();
    die();
}