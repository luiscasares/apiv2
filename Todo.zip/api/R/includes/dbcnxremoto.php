<?php
/**
 * Conexión a la BD usando PDO en MySQL
 * V 1
 * Autor: Refill Creativo 
 */
$dnspdo ='mysql:host=localhost;dbname=makita';
$username="makita";
$passwd="M4k1Ta00x#";
try {
    $pdocnx = new PDO($dnspdo, $username, $passwd);
    echo "conexion";
} catch (PDOException $exc) {
    echo $exc->getTraceAsString();
    echo $exc->getMessage();
    die();
}