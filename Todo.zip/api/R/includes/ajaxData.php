<?php
 include_once 'dbcnx.php';
 $ID = filter_input(INPUT_POST, 'idEstado');
 //$_POST['idEstado']
//$_POST['idEstado']
 if(!empty(filter_input(INPUT_POST, 'idEstado'))){
   
     $queryDistribuidor = "SELECT * FROM distribuidores WHERE idEstado = ".filter_input(INPUT_POST, 'idEstado')." AND activo = 1 ORDER BY nombreDistribuidor ASC";
     
     $stDistri = $pdocnx->prepare($queryDistribuidor);
     $stDistri->execute();
     $resultadosDistribuidores=$stDistri->fetchAll();
     foreach ($resultadosDistribuidores as $salidaDistribuidores){        
         echo '<option value="'.$salidaDistribuidores['nombreDistribuidor'].'">'.$salidaDistribuidores['nombreDistribuidor'].'</option>';
     }
 }else{
     echo '<option value="">No hay un Distribuidor en el Estado seleccionado</option>';
 }
 
 if(!empty(filter_input(INPUT_POST, 'nomDis'))){
     $queryDirDis = "SELECT * FROM distribuidores WHERE nombreDistribuidor = ". filter_input(INPUT_POST, 'nomDis')."  AND activo = 1 ORDER BY nombreDistribuidor ASC";
     $stDirDis = $pdocnx->prepare($queryDirDis);
     $stDirDis->execute();
     foreach ($resultadosDirDis as $salidaDirDis){        
         echo '<input type="text" name="dirDis" id="dirDis" value="'.$salidaDirDir['direccionDistribuidor'].'"  />';
     }
 }else{
     echo '<input value="No hat datos else php" placeholder="entro a php"/>';
 }